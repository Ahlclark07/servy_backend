const User = require("../../models/user");
const Commande = require("../../models/commande");

const admin = require("../../config/firebase-config");
const { getCurrentUser } = require("../../utils/getCurrentUser");
const FcmToken = require("../../models/fcmToken.js");
const fs = require("fs");
const appRoot = require("app-root-path");
exports.userRole = (req, res, next) => {
  User.findOne({ idFirebase: req.params.id })
    .then((user) => {
      res.status(200).json(user.role);
    })
    .catch((error) => {
      res.status(404).json({
        error: error,
      });
    });
};

exports.updateUserInfo = async (req, res, next) => {
  try {
    // Récupérer l'utilisateur actuel à partir de la demande
    const user = await getCurrentUser(req);

    // Vérifier si l'utilisateur existe
    if (!user) {
      return res.status(404).json({
        message: "Utilisateur non trouvé",
      });
    }
    const updateFields = {
      departement: req.body.departement,
      ville: req.body.ville,
      quartier: req.body.quartier,
      localisationMap: req.body.localisationMap,
    };
    if (req.files["photo"]) {
      updateFields.photoDeProfil = req.files["photo"][0].path;
    }
    await User.updateOne({ _id: user._id }, updateFields);
    res.status(200).json({
      message: "Informations utilisateur mises à jour avec succès!",
    });
  } catch (error) {
    // Gérer les erreurs
    res.status(500).json({
      message: "Erreur lors de la mise à jour des informations utilisateur",
      error: error.message,
    });
  }
};

exports.registerFcmToken = async (req, res, next) => {
  try {
    const user = await getCurrentUser(req);
    const token = req.body.token;
    const isAdmin = req.body.isAdmin || false;
    const fcmToken = new FcmToken({
      user: user,
      token: token,
      isAdmin: isAdmin,
    });

    await fcmToken
      .save()
      .then((token) => {
        res.status(201).json({ message: "Token FCM enregistré avec succès" });
      })
      .catch((error) => {
        res.status(404).json({
          error: error,
        });
      });
  } catch (error) {
    console.error("Erreur lors de l'enregistrement du token FCM :", error);
    res.status(500).json({
      error: "Une erreur s'est produite lors de l'enregistrement du token FCM.",
    });
  }
};

exports.placeOrder = async (req, res, next) => {
  const commande = new Commande({
    prestataire: req.body.prestataire,
    client: await getCurrentUser(req),
    service: req.body.service,
    statut: "en_attente",
    montantPaye: req.body.montantPaye,
    //TODO
  });
};
