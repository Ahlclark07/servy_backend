const User = require("../../models/user");
const admin = require("../../config/firebase-config");
const Adresse = require("../../models/adresse");
exports.becomeClient = (req, res, next) => {
  //Récupérer le token d'authentification de l'utilisateur à partir de la requête
  const idToken = req.headers.authorization.split(" ")[1];

  // Vérifier le token d'authentification et extraire l'ID de l'utilisateur
  admin
    .auth()
    .verifyIdToken(idToken)
    .then(async (decodedToken) => {
      const userId = decodedToken.uid;
      const userEmail = decodedToken.email;

      const adresse = await Adresse.create({
        departement: req.body.departement,
        ville: req.body.ville,
        quartier: req.body.quartier,
        localisationMap: req.body.localisationMap,
        informations: req.body.informations,
      });
      // Créer un nouvel utilisateur avec l'ID de l'utilisateur récupéré
      const user = new User({
        idFirebase: userId,
        role: "client",
        nom: req.body.nom,
        prenoms: req.body.prenoms,
        email: userEmail,
        dateDeNaissance: req.body.dateDeNaissance,
        adresses: [adresse._id],
      });

      // Enregistrer l'utilisateur dans la base de données
      user
        .save()
        .then(() => {
          res.status(201).json({
            message: "Client enregistré avec succès!",
          });
        })
        .catch((error) => {
          res.status(400).json({
            error: error,
          });
        });
    })
    .catch((error) => {
      // Gérer les erreurs de vérification du token d'authentification
      res.status(401).json({
        error: "Erreur de vérification du token d'authentification",
      });
    });
};
