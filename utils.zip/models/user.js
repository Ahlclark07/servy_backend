const mongoose = require("mongoose");
const uniqueValidator = require("mongoose-unique-validator");

const roles = ["client", "vendeur", "vendeur pro"];
// Définition du schéma utilisateur
const userSchema = new mongoose.Schema({
  idFirebase: {
    type: String,
    unique: true,
    required: true,
  },
  role: {
    type: String,
    enum: roles,
    required: true,
  },
  enTransition: {
    type: Boolean,
    required: true,
    default: false,
  },
  nom: {
    type: String,
    required: true,
  },
  prenoms: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  carteIdentite: {
    type: String,
  },
  photoDeProfil: {
    type: String,
  },
  profession: {
    type: String,
  },
  attestationProfession: {
    type: String,
  },
  dateDeNaissance: {
    type: Date,
    required: true,
  },
  adresses: [{ type: mongoose.Schema.Types.ObjectId, ref: "adresse" }],
});

// Création du modèle utilisateur
userSchema.plugin(uniqueValidator);
const User = mongoose.model("User", userSchema);

module.exports = User;
