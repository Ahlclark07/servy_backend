const mongoose = require('mongoose');

const commandeSchema = new mongoose.Schema({
    prestataire: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', // Référence au modèle User pour le prestataire
        required: true
    },
    client: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', // Référence au modèle User pour le client
        required: true
    },
    satisfieservice: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ServicePrestataire',
        required: true
    },
    statut: {
        type: String,
        enum: ['en_attente', 'en_cours', 'terminee', 'annulee'], // Exemples de statuts possibles
        default: 'en_attente'
    },
    dateCreation: {
        type: Date,
        default: Date.now
    },
    dateDebut: {
        type: Date,
        required: true
    },
    dateFinPrevue: {
        type: Date,
        required: true
    },
    dateFinReelle: {
        type: Date,
    },
    montantPaye: {
        type: Number,
        required: true
    },
    fraisService: {
        type: Number,
        required: true
    },
    fraisMateriel: {
        type: Number
    },
    methodePaiement: {
        type: String
    },
    evaluation: {
        type: Number
    },
});

const Commande = mongoose.model('Commande', commandeSchema);

module.exports = Commande;
